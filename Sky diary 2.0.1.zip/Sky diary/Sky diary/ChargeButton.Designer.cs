﻿namespace Sky_diary
{
    partial class ChargeButton
    {
        /// <summary> 
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur de composants

        /// <summary> 
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas 
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.TexteDescription = new System.Windows.Forms.TextBox();
            this.TexteTitre = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // TexteDescription
            // 
            this.TexteDescription.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TexteDescription.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.TexteDescription.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TexteDescription.Cursor = System.Windows.Forms.Cursors.Default;
            this.TexteDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TexteDescription.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.TexteDescription.Location = new System.Drawing.Point(0, 35);
            this.TexteDescription.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TexteDescription.Multiline = true;
            this.TexteDescription.Name = "TexteDescription";
            this.TexteDescription.ReadOnly = true;
            this.TexteDescription.Size = new System.Drawing.Size(289, 58);
            this.TexteDescription.TabIndex = 2;
            this.TexteDescription.Text = "Description";
            this.TexteDescription.MouseClick += new System.Windows.Forms.MouseEventHandler(this.TexteDescription_MouseClick);
            this.TexteDescription.DoubleClick += new System.EventHandler(this.TexteDescription_DoubleClick);
            this.TexteDescription.MouseEnter += new System.EventHandler(this.AllControl_MouseEnter);
            this.TexteDescription.MouseLeave += new System.EventHandler(this.AllControl_MouseLeave);
            // 
            // TexteTitre
            // 
            this.TexteTitre.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TexteTitre.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.TexteTitre.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TexteTitre.Cursor = System.Windows.Forms.Cursors.Default;
            this.TexteTitre.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TexteTitre.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.TexteTitre.Location = new System.Drawing.Point(44, 0);
            this.TexteTitre.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TexteTitre.Name = "TexteTitre";
            this.TexteTitre.ReadOnly = true;
            this.TexteTitre.Size = new System.Drawing.Size(189, 24);
            this.TexteTitre.TabIndex = 3;
            this.TexteTitre.Text = "Titre";
            this.TexteTitre.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TexteTitre.MouseClick += new System.Windows.Forms.MouseEventHandler(this.TexteTitre_MouseClick);
            this.TexteTitre.DoubleClick += new System.EventHandler(this.TexteTitre_DoubleClick);
            this.TexteTitre.MouseEnter += new System.EventHandler(this.AllControl_MouseEnter);
            this.TexteTitre.MouseLeave += new System.EventHandler(this.AllControl_MouseLeave);
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button1.Location = new System.Drawing.Point(318, 15);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(88, 58);
            this.button1.TabIndex = 4;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 10;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // ChargeButton
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Controls.Add(this.button1);
            this.Controls.Add(this.TexteTitre);
            this.Controls.Add(this.TexteDescription);
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "ChargeButton";
            this.Size = new System.Drawing.Size(438, 96);
            this.DoubleClick += new System.EventHandler(this.ChargeButton_DoubleClick);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.ChargeButton_MouseClick);
            this.MouseEnter += new System.EventHandler(this.AllControl_MouseEnter);
            this.MouseLeave += new System.EventHandler(this.AllControl_MouseLeave);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TexteDescription;
        private System.Windows.Forms.TextBox TexteTitre;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Timer timer1;
    }
}
