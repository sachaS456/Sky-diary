﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Sky_diary
{
    internal partial class FormPrincipal : Form
    {
        private bool FormCache = false;
        private int Coter = 0;
        private bool FormDeplace = false;
        private int LocX = 0;
        private int LocY = 0;
        private const int MiniLargeForm = 1003;
        private const int MiniHautForm = 575;
        private List<ChargeButton> ListButton = new List<ChargeButton>();
        private int IDSelect = -1;
        private string TitleSave = string.Empty;
        private string NameSave = string.Empty;
        private bool CloseApp = true;

        internal FormPrincipal(string TitleSavec, string NameSavec)
        {
            InitializeComponent();

            this.Opacity = 0;
            timer1.Enabled = true;

            TitleSave = TitleSavec;
            NameSave = NameSavec;
            Read();
        }

        #region FormConfig
        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Maximized)
            {
                this.WindowState = FormWindowState.Normal;
            }
            else
            {
                this.WindowState = FormWindowState.Maximized;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            // animation de form arrêt ou démarre
            if (FormCache == false)
            {
                if (Opacity <= 0.99)
                {
                    Opacity += 0.05;
                }
                else
                {
                    timer1.Enabled = false;
                    FormCache = true;
                }
            }
            else
            {
                if (Opacity >= 0.01)
                {
                    Opacity -= 0.05;
                }
                else
                {
                    timer1.Enabled = false;
                    if (CloseApp)
                    {
                        Environment.Exit(0);
                    }
                    else
                    {
                        this.Dispose();
                    }
                }
            }
        }

        private void FormPrincipal_FormClosing(object sender, FormClosingEventArgs e)
        {
            timer1.Enabled = true;
            e.Cancel = true;
        }

        private void FormPrincipal_MouseDown(object sender, MouseEventArgs e)
        {
            // déplacement active car souris préssée
            if (e.Button == MouseButtons.Left && this.Cursor == Cursors.Default)
            {
                LocX = e.X;
                LocY = e.Y;

                FormDeplace = true;
                return;
            }

            if (this.Cursor != Cursors.Default)
            {
                /// Coin :

                if (e.X >= this.Size.Width - 2 && e.Y >= this.Size.Height - 2)
                {
                    // agrandit ou réduit coin bas droite
                    Coter = 8;
                    timer2.Enabled = true;
                    return;
                }

                if (e.X <= 2 && e.Y >= this.Size.Height - 2)
                {
                    // agrandit ou réduit coin bas gauche
                    Coter = 7;
                    timer2.Enabled = true;
                    return;
                }

                if (e.X >= this.Size.Width - 2 && e.Y <= 2)
                {
                    // agrandit ou réduit coin haut droite
                    Coter = 5;
                    timer2.Enabled = true;
                    return;
                }

                if (e.X <= 2 && e.Y <= 2)
                {
                    // agrandit ou réduit coin haut gauche
                    Coter = 6;
                    timer2.Enabled = true;
                    return;
                }

                /// cotée :

                if (e.X == 0)
                {
                    // agrandit ou réduit coté gauche

                    Coter = 2;
                    timer2.Enabled = true;
                    return;
                }

                if (e.X == this.Size.Width - 1)
                {
                    // agrandit ou réduit coté droite

                    Coter = 1;
                    timer2.Enabled = true;
                    return;
                }

                if (e.Y == this.Size.Height - 1)
                {
                    // agrandit ou réduit coté bas
                    Coter = 4;
                    timer2.Enabled = true;
                    return;
                }

                if (e.Y == 0)
                {
                    // agrandit ou réduit coté haut
                    Coter = 3;
                    timer2.Enabled = true;
                    return;
                }
            }
        }

        private void FormPrincipal_MouseUp(object sender, MouseEventArgs e)
        {
            timer2.Enabled = false;
            Coter = 0;
            FormDeplace = false;
        }

        private void FormPrincipal_MouseMove(object sender, MouseEventArgs e)
        {
            // déplacement de la fenêtre
            if (FormDeplace == true)
            {
                this.Location = new Point(MousePosition.X - LocX, MousePosition.Y - LocY);
            }

            this.Cursor = Cursors.Default;
            button2.Cursor = Cursors.Default;

            if (e.X >= this.Size.Width - 2 && e.Y >= this.Size.Height - 2)
            {
                // agrandit ou réduit coin bas droite
                this.Cursor = Cursors.SizeNWSE;
                return;
            }

            if (e.X <= 2 && e.Y >= this.Size.Height - 2)
            {
                // agrandit ou réduit coin bas gauche
                this.Cursor = Cursors.SizeNESW;
                return;
            }

            if (e.X <= 2 && e.Y <= 2)
            {
                // agrandit ou réduit coin haut gauche
                this.Cursor = Cursors.SizeNWSE;
                return;
            }

            if (e.X == this.Size.Width - 1)
            {
                // agrandit ou réduit coté droite
                this.Cursor = Cursors.SizeWE;
                button2.Cursor = Cursors.SizeWE;
                return;
            }

            if (e.X == 0)
            {
                // agrandit ou réduit coté gauche
                this.Cursor = Cursors.SizeWE;
                return;
            }

            if (e.Y == this.Size.Height - 1)
            {
                // agrandit ou réduit coté bas
                this.Cursor = Cursors.SizeNS;
                return;
            }

            if (e.Y == 0)
            {
                // agrandit ou réduit coté haut
                this.Cursor = Cursors.SizeNS;
                button2.Cursor = Cursors.SizeNS;
                return;
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            switch (Coter)
            {
                case 1:  // côtée droit
                    if (MousePosition.X - this.Location.X >= MiniLargeForm)
                    {
                        this.Size = new Size(MousePosition.X - this.Location.X, this.Size.Height);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, this.Size.Height);
                    }
                    break;

                case 2: // côtée gauche
                    if (this.Size.Width - (MousePosition.X - this.Location.X) >= MiniLargeForm)
                    {
                        this.Size = new Size(this.Size.Width - (MousePosition.X - this.Location.X), this.Size.Height);
                        this.Location = new Point(MousePosition.X, this.Location.Y);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, this.Size.Height);
                    }
                    break;

                case 3:  // côtée haut
                    if (this.Size.Height - (MousePosition.Y - this.Location.Y) >= MiniHautForm)
                    {
                        this.Size = new Size(this.Size.Width, this.Size.Height - (MousePosition.Y - this.Location.Y));
                        this.Location = new Point(this.Location.X, MousePosition.Y);
                    }
                    else
                    {
                        this.Size = new Size(this.Size.Width, MiniHautForm);
                    }
                    break;

                case 4:  // côtée bas
                    if (MousePosition.Y - this.Location.Y >= MiniHautForm)
                    {
                        this.Size = new Size(this.Size.Width, MousePosition.Y - this.Location.Y);
                    }
                    else
                    {
                        this.Size = new Size(this.Size.Width, MiniHautForm);
                    }
                    break;

                case 5:  // coin haut droit
                    if (MousePosition.X - this.Location.X >= MiniLargeForm && this.Size.Height - (MousePosition.Y - this.Location.Y) >= MiniHautForm)
                    {
                        this.Size = new Size(MousePosition.X - this.Location.X, this.Size.Height - (MousePosition.Y - this.Location.Y));
                        this.Location = new Point(this.Location.X, MousePosition.Y);
                    }
                    else if (MousePosition.X - this.Location.X >= MiniLargeForm)
                    {
                        this.Size = new Size(MousePosition.X - this.Location.X, MiniHautForm);
                    }
                    else if (this.Size.Height - (MousePosition.Y - this.Location.Y) >= MiniHautForm)
                    {
                        this.Size = new Size(MiniLargeForm, this.Size.Height - (MousePosition.Y - this.Location.Y));
                        this.Location = new Point(this.Location.X, MousePosition.Y);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, MiniHautForm);
                    }
                    break;

                case 6:  // coin haut gauche
                    if (this.Size.Width - (MousePosition.X - this.Location.X) >= MiniLargeForm && this.Size.Height - (MousePosition.Y - this.Location.Y) >= MiniHautForm)
                    {
                        this.Size = new Size(this.Size.Width - (MousePosition.X - this.Location.X), this.Size.Height - (MousePosition.Y - this.Location.Y));
                        this.Location = new Point(MousePosition.X, MousePosition.Y);
                    }
                    else if (this.Size.Width - (MousePosition.X - this.Location.X) >= MiniLargeForm)
                    {
                        this.Size = new Size(this.Size.Width - (MousePosition.X - this.Location.X), MiniHautForm);
                        this.Location = new Point(MousePosition.X, this.Location.Y);
                    }
                    else if (this.Size.Height - (MousePosition.Y - this.Location.Y) >= MiniHautForm)
                    {
                        this.Size = new Size(MiniLargeForm, this.Size.Height - (MousePosition.Y - this.Location.Y));
                        this.Location = new Point(this.Location.X, MousePosition.Y);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, MiniHautForm);
                    }
                    break;

                case 7:  // coin bas gauche
                    if (this.Size.Width - (MousePosition.X - this.Location.X) >= MiniLargeForm && MousePosition.Y - this.Location.Y >= MiniHautForm)
                    {
                        this.Size = new Size(this.Size.Width - (MousePosition.X - this.Location.X), MousePosition.Y - this.Location.Y);
                        this.Location = new Point(MousePosition.X, this.Location.Y);
                    }
                    else if (this.Size.Width - (MousePosition.X - this.Location.X) >= MiniLargeForm)
                    {
                        this.Size = new Size(this.Size.Width - (MousePosition.X - this.Location.X), MiniHautForm);
                        this.Location = new Point(MousePosition.X, this.Location.Y);
                    }
                    else if (MousePosition.Y - this.Location.Y >= MiniHautForm)
                    {
                        this.Size = new Size(MiniLargeForm, MousePosition.Y - this.Location.Y);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, MiniHautForm);
                    }
                    break;

                case 8:  // coin bas droit
                    if (MousePosition.X - this.Location.X >= MiniLargeForm && MousePosition.Y - this.Location.Y >= MiniHautForm)
                    {
                        this.Size = new Size(MousePosition.X - this.Location.X, MousePosition.Y - this.Location.Y);
                    }
                    else if (MousePosition.X - this.Location.X >= MiniLargeForm)
                    {
                        this.Size = new Size(MousePosition.X - this.Location.X, MiniHautForm);
                    }
                    else if (MousePosition.Y - this.Location.Y >= MiniHautForm)
                    {
                        this.Size = new Size(MiniLargeForm, MousePosition.Y - this.Location.Y);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, MiniHautForm);
                    }
                    break;
            }
        }

        private void button1_MouseMove(object sender, MouseEventArgs e)
        {
            button2.Cursor = Cursors.Default;


            if (e.X >= button1.Size.Width - 2 && e.Y <= 2)
            {
                // agrandit ou réduit coin haut droite
                button1.Cursor = Cursors.SizeNESW;
                return;
            }

            if (e.X == button1.Size.Width - 1)
            {
                // droite
                button1.Cursor = Cursors.SizeWE;
                return;
            }

            if (e.Y == 1)
            {
                // haut
                button1.Cursor = Cursors.SizeNS;
                return;
            }
        }

        private void button1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.X >= button1.Size.Width - 2 && e.Y <= 2)
            {
                // agrandit ou réduit coin haut droite
                Coter = 5;
                timer2.Enabled = true;
                return;
            }

            if (e.X == button1.Size.Width - 2)
            {
                // agrandit ou réduit coté droite

                Coter = 1;
                timer2.Enabled = true;
                return;
            }

            if (e.Y == 1)
            {
                // agrandit ou réduit coté haut
                Coter = 3;
                timer2.Enabled = true;
                return;
            }
        }
        #endregion

        private void button4_Click(object sender, EventArgs e)
        {
            // Add task

            if (ListButton.Count() == 0)
            {
                ChargeButton chargeButton = new ChargeButton(0, pictureBox2.Image, pictureBox3.Image, pictureBox4.Image);
                chargeButton.Location = new Point(0, 0);
                chargeButton.ChargeType = TypeCharge.TacheNonFaite;
                chargeButton.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
                chargeButton.EventClique += new EventIDHandler(chargeButton_Clique);
                chargeButton.EventImageChange += new EventIDImageHandler(chargeButton_ImageChange);
                panel2.Controls.Add(chargeButton);
                ListButton.Add(chargeButton);
            }
            else
            {
                ChargeButton chargeButton = new ChargeButton(ListButton.Count(), pictureBox2.Image, pictureBox3.Image, pictureBox4.Image);
                chargeButton.Location = new Point(0, ListButton[ListButton.Count() - 1].Location.Y + ListButton[ListButton.Count() - 1].Size.Height + 1);
                chargeButton.ChargeType = TypeCharge.TacheNonFaite;
                chargeButton.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
                chargeButton.Size = new Size(ListButton[ListButton.Count() - 1].Size.Width, chargeButton.Size.Height);
                chargeButton.EventClique += new EventIDHandler(chargeButton_Clique);
                chargeButton.EventImageChange += new EventIDImageHandler(chargeButton_ImageChange);
                panel2.Controls.Add(chargeButton);
                ListButton.Add(chargeButton);
            }

            Save();
        }

        private void chargeButton_ImageChange(int ID, ref Image image)
        {
            Save();
        }

        private void chargeButton_Clique(int ID)
        {
            for (int index = 0; index < ListButton.Count(); index++)
            {
                ListButton[index].BorderStyle = BorderStyle.None;
            }

            IDSelect = ID;
            ListButton[ID].BorderStyle = BorderStyle.FixedSingle;
            textBox1.Text = ListButton[ID].DescriptionTexteF;
            textBox2.Text = ListButton[ID].TexteTitreF;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // Delete task selected

            if (MessageBox.Show("Êtes vous sûr de vouloir supprimer cette tâche?", "Sky diary", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                for (int index = 0; index < ListButton.Count(); index++)
                {
                    if (ListButton[index].BorderStyle == BorderStyle.FixedSingle)
                    {
                        ListButton[index].Dispose();
                        ListButton[index] = null;
                        panel2.Controls.Remove(ListButton[index]);
                        ListButton.Remove(ListButton[index]);

                        foreach (ChargeButton i in ListButton)
                        {
                            if (i.ID >= index)
                            {
                                i.ID -= 1;
                                i.Location = new Point(0, i.Location.Y - i.Size.Height);
                            }
                        }
                    }
                }

                Save();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            CloseApp = false;
            timer1.Enabled = true;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (IDSelect != -1)
            {
                ListButton[IDSelect].DescriptionTexteF = textBox1.Text;               
            }

            Save();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (IDSelect != -1)
            {
                ListButton[IDSelect].TexteTitreF = textBox2.Text;
            }

            Save();
        }

        private void Save()
        {
            Directory.Delete(NameSave, true);
            Directory.CreateDirectory(NameSave);
            StreamWriter streamWriter = new StreamWriter(NameSave + @"\title");
            streamWriter.Write(TitleSave);
            streamWriter.Close();
            streamWriter = null;

            int nbTache = ListButton.Count();
            for (int index = 0; index < nbTache; index++)
            {
                Directory.CreateDirectory(NameSave + @"\Task " + index);

                using (StreamWriter writer = new StreamWriter(NameSave + @"\Task " + index + @"\TaskType"))
                {
                    writer.Write(ListButton[index].ChargeType);
                    writer.Close();
                }

                if (ListButton[index].TexteTitreF == "TaskType" || ListButton[index].TexteTitreF == string.Empty)
                {
                    MessageBox.Show("Vous ne pouvez pas appelez votre tâche comme ceci!", "Sky diary", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    ListButton[index].TexteTitreF = "titre";
                }

                using (StreamWriter writer2 = new StreamWriter(NameSave + @"\Task " + index + @"\" + ListButton[index].TexteTitreF))
                {
                    writer2.Write(ListButton[index].DescriptionTexteF);
                    writer2.Close();
                }
            }
        }

        private void Read()
        {
            foreach (string i in Directory.EnumerateDirectories(NameSave))
            {
                if (ListButton.Count() == 0)
                {
                    ChargeButton chargeButton = new ChargeButton(0, pictureBox2.Image, pictureBox3.Image, pictureBox4.Image);
                    chargeButton.Location = new Point(0, 0);
                    chargeButton.ChargeType = TypeCharge.TacheNonFaite;
                    chargeButton.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
                    chargeButton.EventClique += new EventIDHandler(chargeButton_Clique);
                    chargeButton.EventImageChange += new EventIDImageHandler(chargeButton_ImageChange);
                    foreach (string i2 in Directory.EnumerateFiles(i))
                    {
                        if (Path.GetFileNameWithoutExtension(i2) == "TaskType")
                        {
                            using (StreamReader reader = new StreamReader(i2))
                            {
                                chargeButton.ChargeType = Convert.ToSByte(reader.ReadLine());
                                reader.Close();
                            }
                        }
                        else
                        {
                            chargeButton.TexteTitreF = Path.GetFileNameWithoutExtension(i2);

                            using (StreamReader reader = new StreamReader(i2))
                            {
                                chargeButton.DescriptionTexteF = reader.ReadToEnd();
                                reader.Close();
                            }
                        }
                    }
                    panel2.Controls.Add(chargeButton);
                    ListButton.Add(chargeButton);
                }
                else
                {
                    ChargeButton chargeButton = new ChargeButton(ListButton.Count(), pictureBox2.Image, pictureBox3.Image, pictureBox4.Image);
                    chargeButton.Location = new Point(0, ListButton[ListButton.Count() - 1].Location.Y + ListButton[ListButton.Count() - 1].Size.Height + 1);
                    chargeButton.ChargeType = TypeCharge.TacheNonFaite;
                    chargeButton.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
                    chargeButton.Size = new Size(ListButton[ListButton.Count() - 1].Size.Width, chargeButton.Size.Height);
                    chargeButton.EventClique += new EventIDHandler(chargeButton_Clique);
                    chargeButton.EventImageChange += new EventIDImageHandler(chargeButton_ImageChange);
                    foreach (string i2 in Directory.EnumerateFiles(i))
                    {
                        if (Path.GetFileNameWithoutExtension(i2) == "TaskType")
                        {
                            using (StreamReader reader = new StreamReader(i2))
                            {
                                chargeButton.ChargeType = Convert.ToSByte(reader.ReadLine());
                                reader.Close();
                            }
                        }
                        else
                        {
                            chargeButton.TexteTitreF = Path.GetFileNameWithoutExtension(i2);

                            using (StreamReader reader = new StreamReader(i2))
                            {
                                chargeButton.DescriptionTexteF = reader.ReadToEnd();
                                reader.Close();
                            }
                        }
                    }
                    panel2.Controls.Add(chargeButton);
                    ListButton.Add(chargeButton);
                }
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            new InfoApp().ShowDialog();
        }
    }
}
