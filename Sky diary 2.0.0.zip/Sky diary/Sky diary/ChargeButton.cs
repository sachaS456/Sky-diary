﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sky_diary
{
    internal delegate void EventIDHandler(int ID);
    internal delegate void EventIDImageHandler(int ID, ref Image img);

    internal partial class ChargeButton : UserControl
    {
        internal int ID = 0;
        internal event EventIDHandler EventClique = null;
        internal event EventIDHandler EventDouleClique = null;
        internal event EventIDImageHandler EventImageChange = null;
        private Image Fait = null;
        private Image NonFait = null;
        private Image EnCour = null;

        internal ChargeButton(int IDc, Image FaitR, Image EnCourR, Image NonFaitR)
        {
            InitializeComponent();

            ID = IDc;
            Fait = FaitR;
            NonFait = NonFaitR;
            EnCour = EnCourR;
        }

        internal Color ButtonColor
        {
            get
            {
                return this.BackColor;
            }
            set
            {
                this.BackColor = value;
                TexteDescription.BackColor = value;
                TexteTitre.BackColor = value;
            }
        }

        internal sbyte ChargeType
        {
            get
            {
                if (button1.BackgroundImage == Fait)
                {
                    return TypeCharge.TacheFaite;
                }
                else if (button1.BackgroundImage == EnCour)
                {
                    return TypeCharge.TacheEnCours;
                }
                else
                {
                    return TypeCharge.TacheNonFaite;
                }
            }
            set
            {
                switch (value)
                {
                    case TypeCharge.TacheFaite:
                        button1.BackgroundImage = Fait;
                        break;

                    case TypeCharge.TacheEnCours:
                        button1.BackgroundImage = EnCour;
                        break;

                    case TypeCharge.TacheNonFaite:
                        button1.BackgroundImage = NonFait;
                        break;
                }
            }
        }

        internal string DescriptionTexteF
        {
            get
            {
                return TexteDescription.Text;
            }
            set
            {
                TexteDescription.Text = value;
            }
        }

        internal string TexteTitreF
        {
            get
            {
                return TexteTitre.Text;
            }
            set
            {
                TexteTitre.Text = value;
            }
        }

        private void AllControl_MouseEnter(object sender, EventArgs e)
        {
            this.BackColor = Color.FromArgb(100, 100, 100);
            TexteDescription.BackColor = Color.FromArgb(100, 100, 100);
            TexteTitre.BackColor = Color.FromArgb(100, 100, 100);
        }

        private void AllControl_MouseLeave(object sender, EventArgs e)
        {
            this.BackColor = Color.FromArgb(64, 64, 64);
            TexteDescription.BackColor = Color.FromArgb(64, 64, 64);
            TexteTitre.BackColor = Color.FromArgb(64, 64, 64);
        }

        private void TexteDescription_MouseClick(object sender, MouseEventArgs e)
        {
            ExecuterEvenementClique();          
        }

        private void TexteTitre_MouseClick(object sender, MouseEventArgs e)
        {
            ExecuterEvenementClique();
        }

        private void ChargeButton_MouseClick(object sender, MouseEventArgs e)
        {
            ExecuterEvenementClique();
        }

        protected virtual void ExecuterEvenementClique()
        {
            if (EventClique != null)
            {
                EventClique(ID);
            }
        }

        private void TexteDescription_DoubleClick(object sender, EventArgs e)
        {
            ExecuterEvenementDoubleClique();
        }

        private void TexteTitre_DoubleClick(object sender, EventArgs e)
        {
            ExecuterEvenementDoubleClique();
        }

        private void ChargeButton_DoubleClick(object sender, EventArgs e)
        {
            ExecuterEvenementDoubleClique();
        }

        protected virtual void ExecuterEvenementDoubleClique()
        {
            if (EventDouleClique != null)
            {
                EventDouleClique(ID);
            }
        }

        protected virtual void ExecuterEvenementImageChange(Image imgSelect)
        {
            if (EventImageChange != null)
            {
                EventImageChange(ID, ref imgSelect);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (button1.BackgroundImage == Fait)
            {
                button1.BackgroundImage = NonFait;
                ExecuterEvenementImageChange(NonFait);
                return;
            }
            else if (button1.BackgroundImage == NonFait)
            {
                button1.BackgroundImage = EnCour;
                ExecuterEvenementImageChange(EnCour);
                return;
            }
            else
            {
                button1.BackgroundImage = Fait;
                ExecuterEvenementImageChange(Fait);
                return;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (TexteDescription.SelectionLength != 0)
            {
                TexteDescription.DeselectAll();
                button1.Select();
            }

            if (TexteTitre.SelectionLength != 0)
            {
                TexteTitre.DeselectAll();
                button1.Select();
            }
        }
    }

    internal struct TypeCharge
    {
        internal const sbyte TacheFaite = 1;
        internal const sbyte TacheEnCours = 2;
        internal const sbyte TacheNonFaite = 3;
    }
}
