using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Sky_updater;
using System.Threading;

namespace Sky_diary
{
    public static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        public static void Main()
        {
            Application.SetHighDpiMode(HighDpiMode.DpiUnaware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Thread thread = new Thread(new ThreadStart(CheckUpdate));
            thread.Priority = ThreadPriority.Highest;
            thread.Start();

            Application.Run(new FormMenu());
        }

        private static void CheckUpdate()
        {
            Update.CheckUpdate("Sky diary", Application.ProductVersion);
        }
    }
}
