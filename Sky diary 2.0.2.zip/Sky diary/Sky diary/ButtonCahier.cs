﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sky_diary
{
    internal partial class ButtonCahier : UserControl
    {
        internal event EventIDHandler EventClique = null;
        internal event EventIDHandler EventDelete = null;
        private int IDv = 0;
        private string NameSavev = string.Empty;
        private bool DeSelectTexte = true;

        internal ButtonCahier(int IDc)
        {
            InitializeComponent();

            IDv = IDc;
        }

        internal string NameText
        {
            get
            {
                return TexteTitre.Text;
            }
            set
            {
                TexteTitre.Text = value;
            }
        }

        internal string NameSave
        {
            get
            {
                return NameSavev;
            }
            set
            {
                NameSavev = value;
            }
        }

        protected virtual void ExecuterEvenementClique()
        {
            if (EventClique != null)
            {
                EventClique(IDv);
            }
        }

        protected virtual void ExecuterEvenementDelete()
        {
            if (EventDelete != null)
            {
                EventDelete(IDv);
            }
        }

        internal int ID
        {
            get
            {
                return IDv;
            }
            set
            {
                IDv = value;
            }
        }

        private void ButtonCahier_MouseClick(object sender, MouseEventArgs e)
        {
            ExecuterEvenementClique();
        }

        private void ButtonCahier_MouseEnter(object sender, EventArgs e)
        {
            this.BackColor = Color.FromArgb(100, 100, 100);
            TexteTitre.BackColor = Color.FromArgb(100, 100, 100);
        }

        private void ButtonCahier_MouseLeave(object sender, EventArgs e)
        {
            this.BackColor = Color.FromArgb(64, 64, 64);
            TexteTitre.BackColor = Color.FromArgb(64, 64, 64);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // delete control
            ExecuterEvenementDelete();
        }

        private void TexteTitre_MouseEnter(object sender, EventArgs e)
        {
            this.BackColor = Color.FromArgb(100, 100, 100);
            TexteTitre.BackColor = Color.FromArgb(100, 100, 100);
        }

        private void TexteTitre_MouseLeave(object sender, EventArgs e)
        {
            this.BackColor = Color.FromArgb(64, 64, 64);
            TexteTitre.BackColor = Color.FromArgb(64, 64, 64);
        }

        private void TexteTitre_MouseClick(object sender, MouseEventArgs e)
        {
            ExecuterEvenementClique();
        }

        private void ButtonCahier_MouseDown(object sender, MouseEventArgs e)
        {
            this.BackColor = Color.FromArgb(100, 250, 250, 250);
            TexteTitre.BackColor = Color.FromArgb(137, 137, 137);
        }

        private void TexteTitre_MouseDown(object sender, MouseEventArgs e)
        {
            this.BackColor = Color.FromArgb(100, 250, 250, 250);
            TexteTitre.BackColor = Color.FromArgb(137, 137, 137);
            this.Select();
        }

        private void TexteTitre_MouseUp(object sender, MouseEventArgs e)
        {
            this.BackColor = Color.FromArgb(64, 64, 64);
            TexteTitre.BackColor = Color.FromArgb(64, 64, 64);
            this.Select();
        }

        private void ButtonCahier_MouseUp(object sender, MouseEventArgs e)
        {
            this.BackColor = Color.FromArgb(64, 64, 64);
            TexteTitre.BackColor = Color.FromArgb(64, 64, 64);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // rename

            this.Select();
            TexteTitre.Select();
            TexteTitre.SelectAll();
            DeSelectTexte = false;
        }

        private void TexteTitre_TextChanged(object sender, EventArgs e)
        {
            if (NameSavev != string.Empty)
            {
                using (System.IO.StreamWriter writer = new System.IO.StreamWriter(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\Sky diary\" + NameSavev + @"\title"))
                {
                    writer.Write(TexteTitre.Text);
                    writer.Close();
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (TexteTitre.SelectionLength != 0 && DeSelectTexte == true)
            {
                TexteTitre.DeselectAll();
                this.Select();
            }
        }
    }
}
